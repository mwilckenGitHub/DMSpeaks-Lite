@echo off
setlocal DisableDelayedExpansion
set "dmsPython=%LOCALAPPDATA%\DMSpeaksLite\Builds\5996a8fb357ae6741b77\runtime\python\python.exe"
if not exist "%dmsPython%" goto missing
"%dmsPython%" -I -B "%~dp0update_decoder.py"
set "dmsResult=%errorlevel%"
goto finished
:missing
echo Install the Northshire Windows beta before applying this update.
set "dmsResult=1"
:finished
pause
exit /b %dmsResult%
