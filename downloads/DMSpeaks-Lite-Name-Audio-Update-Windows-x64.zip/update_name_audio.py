"""Apply the name audio update to a registered Windows Northshire beta."""

from hashlib import sha256
import os
from pathlib import Path
import sqlite3
import sys
import winreg
from zipfile import BadZipFile


HERE = Path(__file__).resolve().parent
BUILD_DIRECTORY = "5996a8fb357ae6741b77"
FINAL_BUILD = "589ee6ad3643bc4a3e7f9ffd6120572fca6b63260f1203852769a55e5ada0ec6"
MAINTENANCE_FILES = {
    "open_lite.py": "d0b01f0ddc4006ec3da721140df6bb91f473a2291d383412a8f0f514246c4df7",
    "install_addon.py": "859123274927c845a94de33a9ff7f7999f13c83d6482265525d3d83bdb309aff",
}


def registered_game():
    entry = r"Software\Microsoft\Windows\CurrentVersion\Uninstall\DMSpeaksLite"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, entry, access=winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as key:
            active, _ = winreg.QueryValueEx(key, "ActiveBuild")
            folder, _ = winreg.QueryValueEx(key, "GameFolder")
    except FileNotFoundError as error:
        raise ValueError("Install the Northshire Windows beta before applying this update.") from error
    if active != BUILD_DIRECTORY or not folder:
        raise ValueError("This update requires the Northshire Windows beta.")
    game = Path(folder)
    if not game.is_absolute() or not (game / "Interface/AddOns").is_dir():
        raise ValueError("The registered WoW installation could not be found.")
    return game


def apply(package, maintenance, game):
    for name, expected in MAINTENANCE_FILES.items():
        helper = maintenance / name
        if not helper.is_file() or sha256(helper.read_bytes()).hexdigest() != expected:
            raise ValueError("The matching Northshire maintenance files are missing or changed. Run the original Northshire Setup.")
    if not (package / "source/lite_portable_inputs.py").is_file():
        raise ValueError("The Northshire Windows beta files could not be found.")
    archive = HERE / "name-audio.zip"
    if sha256(archive.read_bytes()).hexdigest() != "98a7adfef41baf9d121e14a3a77f038a65169534e00240baef5c6d95ba1bc67f":
        raise ValueError("The name audio update is incomplete. Download it again.")
    sys.path[:0] = [str(HERE), str(maintenance), str(package / "source")]
    from refresh_runtime import refresh
    from open_lite import installed_build_id

    refresh(package, game, archive)
    if installed_build_id(package) != FINAL_BUILD:
        raise ValueError("The installed name audio update could not be verified.")
    print("DMSpeaks Lite name audio update verified. You can open Lite.")


def main():
    install = Path(os.environ["LOCALAPPDATA"]) / "DMSpeaksLite"
    apply(install / "Builds" / BUILD_DIRECTORY, install / "Maintenance", registered_game())


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, sqlite3.Error, BadZipFile) as error:
        print(error, file=sys.stderr)
        raise SystemExit(1)
